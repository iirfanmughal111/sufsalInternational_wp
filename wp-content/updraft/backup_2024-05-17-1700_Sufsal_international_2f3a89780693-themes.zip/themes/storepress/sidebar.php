<?php if ( ! is_active_sidebar( 'storepress-sidebar-primary' ) ) {	return; } ?>
<div class="col-lg-4 col-md-12 col-12">
	<div class="sidebar">
		<?php dynamic_sidebar('storepress-sidebar-primary'); ?>
	</div>
</div>