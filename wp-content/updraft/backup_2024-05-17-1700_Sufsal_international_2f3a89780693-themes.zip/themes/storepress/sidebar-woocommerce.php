<?php if ( ! is_active_sidebar( 'storepress-woocommerce-sidebar' ) ) {	return; } ?>
<div class="col-lg-4 pl-lg-4 order-0">
	<div class="sidebar">
		<?php dynamic_sidebar('storepress-woocommerce-sidebar'); ?>
	</div>
</div>