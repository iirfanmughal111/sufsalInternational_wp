<?php 
/**
Template Name: Frontpage 
*/

get_header(); 

do_action( 'storepress_sections', false );	
	
get_footer(); ?>